# Mensajes de activación de keys

La aplicación muestra estos mensajes cuando `POST /api/public/activate` devuelve el código
correspondiente en el campo JSON `error`:

| Código | Mensaje |
| --- | --- |
| `key_used_other_device`, `device_mismatch`, `used_by_another_device` | `KEY USED POR OTRO DISPOSITIVO` |
| `key_banned`, `banned`, `revoked` | `ESTA KEY FUE BANEADA` |
| `max_devices_reached`, `device_limit_reached`, `key_device_limit` | `LA KEY ALCANZÓ SUS MAX DE DISPOSITIVOS` |

La validación real debe realizarla el servidor. El backend de prueba incluido en
`cloudflare/src/index.js` vincula cada key a un solo dispositivo y no implementa baneos
ni cupos multi-dispositivo; para que esos dos casos funcionen, el backend conectado a la
app debe devolver los códigos anteriores según el estado de la key.
